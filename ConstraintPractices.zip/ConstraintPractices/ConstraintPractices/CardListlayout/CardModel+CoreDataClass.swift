//
//  CardModel+CoreDataClass.swift
//  ConstraintPractices
//
//  Created by P21_0105 on 17/02/22.
//
//

import Foundation
import CoreData

@objc(CardModel)
public class CardModel: NSManagedObject {

}
