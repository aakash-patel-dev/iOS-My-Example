//
//  DataModel.swift
//  ConstraintPractices
//
//  Created by P21_0105 on 16/02/22.
//

import UIKit

struct DataModel {
    var amount : String?
    var cardNumber : String?
    var customerName :String?
    var cvvNum : String?
}
