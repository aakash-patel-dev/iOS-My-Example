//
//  ShowModelViewController.swift
//  ConstraintPractices
//
//  Created by P21-0105 on 14/03/22.
//

import UIKit

class ShowModelViewController: UIViewController {
    
    @IBOutlet weak var scrollView: FAScrollView!
    
    
    
    override func viewDidLoad() {
        
    }
  


}
