//
//  ViewController.swift
//  ConstraintPractices
//
//  Created by P21_0105 on 15/02/22.
//

import UIKit

class ViewController: UIViewController {

//    @IBOutlet weak var secView: UIView!
    @IBOutlet weak var firstView: UIView!
    
//    @IBOutlet weak var thrdView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        firstView.layer.cornerRadius = 10
//        secView.layer.cornerRadius = 10
//        thrdView.layer.cornerRadius = 10
    }


}

