//
//  CustomCollectionViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 23/02/22.
//

import UIKit

class CustomCollectionViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate ,UICollectionViewDelegate,UICollectionViewDataSource{
    
    var imgData : [GalleryModel] = []
    var imagesLabel : [String] = ["test","test","test","test","test","test" ,"test","test","test" ,"test","test","test" ,"test","test","test","test","test","test"]
    var selectedImage = UIImage()
    var currentTime : String = ""

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ImageCollectionViewCell
        cell.imgDateInfo.text = currentTime
        
//        var model = GalleryModel
//        cell.imgGallery.image = UIImage(named: selectedImage)
        print(selectedImage.description)
          return cell

    }
    

    @IBOutlet weak var imgCollectionView: UICollectionView!
    
    var imagePicker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        imgCollectionView.delegate = self
        imgCollectionView.dataSource = self
        imgCollectionView.register(ImageCollectionViewCell.nib, forCellWithReuseIdentifier: "cell")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnImageAddAction(_ sender: UIBarButtonItem) {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imagePicker.delegate  = self
        
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false

            present(imagePicker, animated: true, completion: nil)
        }
        
        
        
    }
    
 
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let timestamp = NSDate().timeIntervalSince1970
        let myTimeInterval = TimeInterval(timestamp)
      
        if let image = info[UIImagePickerController.InfoKey.imageURL] as? UIImage
            {
                selectedImage = image
                currentTime = NSDate(timeIntervalSince1970: TimeInterval(myTimeInterval)).description
                self.imgCollectionView.reloadData()
            }

//        else if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
//            {
//                selectedImage = image
//                currentTime = NSDate(timeIntervalSince1970: TimeInterval(myTimeInterval)).description
//                self.imgCollectionView.reloadData()
//            }

            else
            {
                print("Something went wrong")
            }

            self.dismiss(animated: true, completion: nil)
            
            
    }
}
