//
//  GalleryModel.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 23/02/22.
//

import UIKit

struct GalleryModel  {
    var imgName : String
    var imgLocation : String
    var imgDate : String
//    var imgdate : Date

}
