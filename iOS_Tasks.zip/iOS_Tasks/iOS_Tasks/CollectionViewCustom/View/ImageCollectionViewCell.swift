//
//  ImageCollectionViewCell.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 23/02/22.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgGallery: UIImageView!
    
    @IBOutlet weak var imgDateInfo: UILabel!
    
    static var nib : UINib{
        return UINib(nibName: identifier, bundle: nil)
    }
    static var identifier: String {
        return String(describing: self)
           }
    
    
}
