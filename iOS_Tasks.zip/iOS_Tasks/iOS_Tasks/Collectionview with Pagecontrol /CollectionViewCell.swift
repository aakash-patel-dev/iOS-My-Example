//
//  CollectionViewCell.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 07/02/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
 
    @IBOutlet weak var myCell: UIImageView!
    
}
