//
//  PagerViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 07/02/22.
//

import UIKit

class PagerViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var photos : [String] = ["page1","page2","page3"]

   
    @IBOutlet weak var pageControl: UIPageControl!
    
//    var index = 0
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.myCell.image = UIImage(named: photos[indexPath.row])
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl.currentPage = 0
        pageControl.numberOfPages = photos.count
        // Do any additional setup after loading the view.
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        pageControl.currentPage = indexPath.row
    }

 

}
