//
//  MenuViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 11/02/22.
//

import UIKit

class MenuViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.delegate = self
        
        let menu :UIMenuController = UIMenuController.shared
        
        menu.setMenuVisible(true, animated: true)
        
        menu.arrowDirection = UIMenuController.ArrowDirection.default
        
        menu.setTargetRect(CGRect.zero, in: view)
        
        let menuItem1: UIMenuItem = UIMenuItem(title: "Menu 1", action: #selector(onMenu1(sender:)))
        let menuItem2: UIMenuItem = UIMenuItem(title: "Menu 2", action: #selector(onMenu2(sender:)))
        let menuItem3: UIMenuItem = UIMenuItem(title: "Menu 3", action: #selector(onMenu3(sender:)))
        
        let myMenuItems: [UIMenuItem] = [menuItem1, menuItem2, menuItem3]
        
        menu.menuItems = myMenuItems
        
        
      
        // Do any additional setup after loading the view.
    }
    override func canPerformAction(_ action: Selector, withSender sender: Any!) -> Bool {
                return true
        }
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
        
    @objc func onMenu1(sender: UIMenuItem) {
            print("onMenu1")
        }
        
    @objc func onMenu2(sender: UIMenuItem) {
            print("onMenu2")
        }
        
    @objc   func onMenu3(sender: UIMenuItem) {
            print("onMenu3")
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
