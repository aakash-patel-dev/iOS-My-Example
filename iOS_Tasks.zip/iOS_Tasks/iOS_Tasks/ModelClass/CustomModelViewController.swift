//
//  CustomModelViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 01/02/22.
//

import UIKit


class CustomModelViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var mobile: UITextField!
    let defaults = UserDefaults.standard
 
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func submit(_ sender: Any) {
        let user =  Model(fname: name.text!, uemail: email.text!, umobile: mobile.text!)
        
        let encode = JSONEncoder()
        
        let encoder = try! encode.encode(user)
        
        defaults.set(encoder, forKey: "Model")
        
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController1 = storyBoard.instantiateViewController(withIdentifier: "modelDetail") as! ModelDetailViewController

        self.present(nextViewController1, animated: true, completion: nil)
        
    }
    
}
