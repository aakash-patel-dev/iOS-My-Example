//
//  Model.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 01/02/22.
//

import UIKit

struct Model : Codable{
    var fname : String
    var uemail : String
    var umobile : String
}
