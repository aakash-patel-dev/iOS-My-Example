//
//  FirstViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 04/02/22.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var text: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func gotoNext(_ sender: Any) {
        guard  let viewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController else {
                  fatalError("View Controller not found")
              }
 
        viewController.delegateupdate = self
        navigationController?.pushViewController(viewController, animated: true)
    }
 

}
extension FirstViewController :didChangeNameDelegate{
    

    func updateName(str: String) {
        text.text = str
    }
    
    
}
