//
//  SecondViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 04/02/22.
//

import UIKit
protocol didChangeNameDelegate{
    func updateName( str : String)
}
class SecondViewController: UIViewController {

    var delegateupdate :didChangeNameDelegate?
    @IBOutlet weak var enterText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func clickToUpdate(_ sender: Any) {
     
        self.delegateupdate?.updateName(str: enterText.text!)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func clicktoNext(_ sender: Any) {
        guard  let viewController = self.storyboard?.instantiateViewController(withIdentifier: "PagerViewController") as? PagerViewController else {
                  fatalError("View Controller not found")
              }
 
        
        navigationController?.pushViewController(viewController, animated: true)
    }
}

 
