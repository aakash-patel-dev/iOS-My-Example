//
//  FormArrayViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 22/02/22.
//

import UIKit

class FormArrayViewController: UIViewController {

    @IBOutlet weak var txtInput: UITextField!
    var arry : [String] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func submit(_ sender: Any) {
        arry.append(txtInput.text!)
        txtInput.text = ""
    }

    @IBAction func goNext(_ sender: Any) {
        guard  let viewController = self.storyboard?.instantiateViewController(withIdentifier: "TableArrayViewController") as? TableArrayViewController else {fatalError("View Controller not found")}
        
        viewController.strArray = arry
        viewController.newName = self
        navigationController?.pushViewController(viewController, animated: true)
        
    }
}

extension FormArrayViewController : newNameDelegate{
    func updateName(str: [String]) {
        arry = str
        print(arry.count)
    }
    
    
}
