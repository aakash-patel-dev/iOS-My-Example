//
//  TableArrayViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 22/02/22.
//

import UIKit

protocol newNameDelegate{
    func updateName( str : [String])
}
class TableArrayViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    var newName : newNameDelegate? = nil
    var strArray : [String] = []
    @IBOutlet weak var tblView: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return strArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let tabCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        tabCell.textLabel?.text = strArray[indexPath.row]
        return tabCell
    
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete) {
            tableView.beginUpdates()
            strArray.remove(at: indexPath.row)
             tableView.deleteRows(at: [indexPath], with: .automatic)
            self.newName?.updateName(str: strArray)
            print(strArray.count)
            tableView.endUpdates()
     
           }
        
    }
 
 
   


    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.delegate = self
        tblView.dataSource = self
        tblView.reloadData()
        // Do any additional setup after loading the view.
    }
    

    

}
