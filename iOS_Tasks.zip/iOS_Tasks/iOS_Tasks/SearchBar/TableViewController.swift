//
//  TableViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 09/02/22.
//

import UIKit

class TableViewController: UITableViewController,UISearchResultsUpdating {
    
    let array = ["one","one","two","three","asdf"]
    
    var filteredTableData = [String]()
    var resultSearchController = UISearchController()
    
    func updateSearchResults(for searchController: UISearchController) {
//        filteredTableData.removeAll(keepingCapacity: false)

//        searchController.searchResultsController?.view.isHidden = false
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text!)
         let finalArray = (array as NSArray).filtered(using: searchPredicate)
        filteredTableData = finalArray as! [String]
        
        self.tableView.reloadData()
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        resultSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.obscuresBackgroundDuringPresentation = false
            controller.searchBar.sizeToFit()
            tableView.tableHeaderView = controller.searchBar
            return controller
        })()
        
        
        tableView.reloadData()
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (resultSearchController.isActive){
            return filteredTableData.count
        }
        else{
            return array.count
        }
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if(resultSearchController.isActive){
            cell.textLabel?.text = filteredTableData[indexPath.row]
            return cell
        }
        else{
            cell.textLabel?.text = array[indexPath.row]
            print(array[indexPath.row])
            return cell
        }
    }



}
