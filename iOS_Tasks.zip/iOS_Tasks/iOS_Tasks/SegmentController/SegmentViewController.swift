//
//  SegmentViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 11/02/22.
//

import UIKit

class SegmentViewController: UIViewController {

    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        segment.selectedSegmentIndex = 0
        let titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
          segment.setTitleTextAttributes(titleTextAttributes, for: .normal)
          segment.setTitleTextAttributes(titleTextAttributes, for: .selected)
        if(segment.selectedSegmentIndex == 0){
            label.text = segment.titleForSegment(at: segment.selectedSegmentIndex)
        }
    }
        

    
    @IBAction func changeSegment(_ sender: Any) {
        
        let control = sender as! UISegmentedControl
        
        if control.tag == 101{
            label.text = control.titleForSegment(at: control.selectedSegmentIndex)
        }
        else{
            label.text = control.titleForSegment(at: control.selectedSegmentIndex)
        }
    }
}
