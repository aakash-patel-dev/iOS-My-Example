//
//  TabViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 02/02/22.
//

import UIKit

class TabViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        createTabBarController()
    }
    

    func createTabBarController(){
//        let tabBar = UITabBarController()
//        tabBar.tabBar.tintColor = UIColor.black
//        let firstVc = UIViewController()
//        firstVc.title = "First"
//        let secondVc = UIViewController()
//        secondVc.title = "Second"
//        tabBar.viewControllers = [firstVc, secondVc]
//        self.view.addSubview(tabBar.view)
//
        
    }

}
