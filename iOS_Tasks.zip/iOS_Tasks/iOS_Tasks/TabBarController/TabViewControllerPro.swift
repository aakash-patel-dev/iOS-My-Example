//
//  TabViewControllerPro.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 02/02/22.
//

import UIKit

class TabViewControllerPro: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
 

}
