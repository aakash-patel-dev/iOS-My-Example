//
//  HeaderView.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 14/02/22.
//

import UIKit

class HeaderView: UITableViewHeaderFooterView {

    @IBOutlet weak var contryName: UILabel!
    
    @IBOutlet weak var addBtn: UIButton!
    
    
    
    static var nib : UINib{
        return UINib(nibName: identifier, bundle: nil)
    }
    static var identifier: String {
        return String(describing: self)
           }
    
}
