//
//  SectionModel.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 15/02/22.
//

import UIKit

struct SectionModel {
    
    var name : [String]
    var isExpanded: Bool 
}
