//
//  SectionViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 14/02/22.
//

import UIKit

class SectionViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    

    @IBOutlet weak var table: UITableView!
    
    let sectionStats = [Bool](repeating: true, count: 2)
    var data = [SectionModel(name: ["Phoenix"], isExpanded: true),SectionModel(name: ["Los Angeles", "San Francisco", "San Jose", "San Diego"], isExpanded: true),SectionModel(name: ["Miami", "Jacksonville"], isExpanded: true),SectionModel(name: ["Chicago"], isExpanded: true), SectionModel(name: ["Buffalo", "New York"], isExpanded: true),
    ]
    var hearderData = [
            "Arizona",
            "California",
            "Florida",
            "Illinois",
            "New York",
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        table.register(HeaderView.nib , forHeaderFooterViewReuseIdentifier: "section")

    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        

        if !data[section].isExpanded{
            return 0
        }
        
        return data[section].name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let name = data[indexPath.section].name
        cell.textLabel?.text = name[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "section") as? HeaderView else{
            return nil
        }
         
        header.contryName.text = hearderData[section]
//        header.addButton.layer.cornerRadius = 10
//        header.addButton.clipsToBounds = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        header.tag = section
        header.addGestureRecognizer(tap)
//        header.addBtn.addAction(UIAction{ [weak self] _ in
//            self?.data[section].name.append("Hello")
////            self?.table.reloadData()
//        },for: .touchUpInside)
//
       
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        
        let section : Int? = sender.view?.tag
        data[section!].isExpanded = !data[section!].isExpanded
        table.reloadData()
        
    }
//        var indexPaths = [IndexPath]()
//
//            for row in data[section!].name.indices{
//                let indexPath = IndexPath(row: row, section: section!)
//                print(row)
//                indexPaths.append(indexPath)
//            }
//
//
//        let isExpanded = data[section!].isExpanded
//
//        data[section!].isExpanded = !isExpanded
//
//        if(isExpanded){
//            table.deleteRows(at: indexPaths, with: .fade)
//        }
//        else{
//             table.insertRows(at: indexPaths, with: .fade)
//        }
//        }
}
