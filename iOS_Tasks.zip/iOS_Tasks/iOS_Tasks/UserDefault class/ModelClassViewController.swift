//
//  ModelClassViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 01/02/22.
//

import UIKit

class ModelClassViewController: UIViewController {
    let defaults = UserDefaults.standard
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        if defaults.bool(forKey: "isLogin") == true {
            defaults.set(false, forKey: "isLogin")
        }
       
    }
    

    @IBAction func submit(_ sender: Any) {
       
        defaults.set(true, forKey: "isLogin")
        defaults.set(name.text, forKey: "nameValue")
        print(defaults.bool(forKey: "isLogin"))
         let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
         let nextViewController = storyBoard.instantiateViewController(withIdentifier: "nextView") as! NextUIControllerViewController

         self.present(nextViewController, animated: true, completion: nil)
    }
    

}
