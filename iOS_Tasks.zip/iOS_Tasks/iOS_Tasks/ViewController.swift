//
//  ViewController.swift
//  iOS_Tasks
//
//  Created by P21_0105 on 31/01/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

